﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrafficLight.Model;
using static TrafficLight.Model.AddModel;

namespace TrafficLight.Controllers
{
    [Route("api/observation")]
    public class Observation : Controller
    {
        [HttpPost, Route("add")]
        public string Add(AddRequest request)
        {
            ListOfRequest List = new ListOfRequest();
            if (List.Request.Count > 0)
            {
                foreach (var item in List.Request)
                {
                    if (item.Sequence == request.Sequence)
                    {
                        List.Request.Add(request);
                    }
                }
            }
            else {
                List.Request.Add(request);
            }

            string FirstNumber = request.Numbers[0];
            string SecondNumber = request.Numbers[1];

            string FirstNumberSequence = "";
            for (int i = 0; i < 7; i++) {
                if (FirstNumber.Substring(i, 1) == "1")
                {
                    FirstNumberSequence = FirstNumberSequence + i;
                }                
            }

            string SecondNumberSequence = "";
            for (int i = 0; i < 7; i++)
            {
                if (SecondNumber.Substring(i, 1) == "1")
                {
                    SecondNumberSequence = SecondNumberSequence + i;
                }
            }

            // Объявляем рабочий светофор


            return FirstNumberSequence + SecondNumberSequence;
        }


    }
}
