﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TrafficLight.Controllers
{
    [Route("api/sequence")]
    public class SequenceController : Controller
    {
        // POST api/values
        [HttpPost, Route("create")]
        public string Create()
        {
            string guid = Guid.NewGuid().ToString();
            return guid;
        }
    }
}
