﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static TrafficLight.Model.AddModel;

namespace TrafficLight.Model
{
    public class AddModel
    {
        public class AddRequest
        {
            public string Color { get; set;}
            public string[] Numbers { get; set; }
            public string Sequence { get; set; }
        }

        public class AddResponse
        {
            public string[] Start { get; set; }
            public string[] Missing { get; set; }
        }
    }
    public class ListOfRequest
    {
        public List<AddRequest> Request { get; set; }
        public ListOfRequest() {
            if (Request is null)
            {
                Request = new List<AddRequest>();
            }
            else {
                Request = Request;
            }
        }
    }




    }
