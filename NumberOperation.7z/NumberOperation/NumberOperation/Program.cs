using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberOperation
{
    class Program
    {
        static void Main(string[] args)
        {

            decimal a = 4.5m;
            double b = 4;
            int c = 9;
            short d = 1;
            long e = 19766;
            float f = 15.5F;
            CalcAverage<object> List = new CalcAverage<object>();
            List.Add(a);
            List.Add(b);
            List.Add(c);
            List.Add(d);
            List.Add(e);
            List.Add(f);

            Console.WriteLine("Hello World!");
            foreach (var item in List)
            {
                Console.WriteLine("ListNumber: " + item);
            }
            Console.WriteLine("AVERAGE: " + List.AverageSum());

            Console.ReadKey();
        }
    }
}
