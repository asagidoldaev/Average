﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberOperation
{
    public class CalcAverage<T>
    {
        public CalcAverage()
        {
            ListNumber = new ArrayList();
        }

        public ArrayList ListNumber { get; set; }
        public void Add(T value)
        {
            ListNumber.Add(value);
        }

        public double AverageSum()
        {
            try
            {
                int count = 0;
                double Sum = 0;
                foreach (var item in ListNumber)
                {
                    count++;
                    Type type = item.GetType();
                    Sum = Sum + Convert.ToDouble(item);
                }
                return Sum / count;
            }
            catch (Exception e)
            {
                return 0;
            }

        }

        public void Reset(T value)
        {
            ListNumber = new ArrayList();
        }

        public IEnumerator GetEnumerator()
        {
            return ListNumber.GetEnumerator();
        }

    }
}
